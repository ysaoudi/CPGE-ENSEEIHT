# Projet hidoop 
## partie HDFS v1

###TODO

- [X] NameNode.

- [X] Redondance des fragments.

- [X] HDFSRead robuste aux pannes

- [ ] Fiabilisation / Redondance du NameNode.

### Bonus
- [ ] Reduire la redondance

- [ ] Script de démmarage des démons.

- [ ] Eviter la redondance si plusieurs daemons sur une même machine.

- [ ] Config ++

- [ ] Répartition intelligente des données selon un paramétrage des machines.

- [ ] Compatibilité Hidoop v1.

- [ ] Map Reduce de Test.

- [ ] Redispatching des donnée (pas franchement convaincu que ça serve).