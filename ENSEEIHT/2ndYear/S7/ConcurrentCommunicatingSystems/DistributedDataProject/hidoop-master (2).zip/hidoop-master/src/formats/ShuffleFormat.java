package formats;

public interface ShuffleFormat extends Format{
//	public void setListRemoteFormat(RemoteFormat[] f);
//	public void setShuffelFunction(ShuffleFunction f);
	
}
