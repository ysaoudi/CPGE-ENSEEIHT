package formats;

public interface ShuffleFunction {
    int shuffle(String key, int maxOutput);
}
