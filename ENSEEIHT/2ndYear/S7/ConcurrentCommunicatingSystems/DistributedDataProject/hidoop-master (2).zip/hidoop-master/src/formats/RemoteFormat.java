package formats;


public interface RemoteFormat extends Format{
//	public void setRemoteNode(String IP, int Port);
//	public void setLocalFormat(Format f);
	
}
