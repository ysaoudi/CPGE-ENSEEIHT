package hdfs;

public enum ECommandType {
    CMD_READ,
    CMD_WRITE,
    CMD_DELETE
}
