package ordo;

public enum State {
    Done,
    Running,
    Suspended,
    NotStarted;
}