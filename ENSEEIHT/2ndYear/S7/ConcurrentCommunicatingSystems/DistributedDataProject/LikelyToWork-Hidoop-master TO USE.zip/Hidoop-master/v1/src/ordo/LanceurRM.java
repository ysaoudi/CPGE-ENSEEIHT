package ordo;

public class LanceurRM {

    public static void main(String[] args) {
    }
}
