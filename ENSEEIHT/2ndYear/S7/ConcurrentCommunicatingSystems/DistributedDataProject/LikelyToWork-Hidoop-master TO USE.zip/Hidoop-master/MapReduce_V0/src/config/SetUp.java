package config;

public class SetUp {
	
	public static int nbServeurs = 3;
	
	public static int[] portsServeurs = {4444, 5555, 6666};
	
	/* Version Locale */
	public static String[] nomServeurs = {"localhost", "localhost", "localhost"};
	
	/* Version réparti */
	//public static String[] machines = {"omble", "truite", "daurade"};
	
	public static String[] nomDaemons = {"Succube", "Lucifer", "Cthun"};
	
}
