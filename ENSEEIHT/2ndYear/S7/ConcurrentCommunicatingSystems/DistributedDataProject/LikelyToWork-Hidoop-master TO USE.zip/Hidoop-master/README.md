# Hidoop
Projet de Système concurrent en double binôme

Groupe Marie/Alexys dans le dossier Hidoop_V0

Groupe Marine/Yanis dans le dossier HDFS_V0

(créez les dossier si c'est pas fait :p (faut les add après :p))
