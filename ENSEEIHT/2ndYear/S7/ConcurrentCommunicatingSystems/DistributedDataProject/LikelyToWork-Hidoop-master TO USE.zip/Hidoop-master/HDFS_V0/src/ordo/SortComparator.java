/* une PROPOSITION, incomplète et adaptable... */

package ordo;
public interface SortComparator {
	public int compare(String k1,String k2);
}