package hdfs;

public enum Commande {CMD_READ , CMD_WRITE , CMD_DELETE };
