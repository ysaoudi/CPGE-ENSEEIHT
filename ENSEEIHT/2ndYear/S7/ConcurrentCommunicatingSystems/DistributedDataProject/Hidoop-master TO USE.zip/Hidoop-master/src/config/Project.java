package config;

public class Project {
	public static String PATH = "~/eclipse-workspace/Hidoop/src/"; 
}
