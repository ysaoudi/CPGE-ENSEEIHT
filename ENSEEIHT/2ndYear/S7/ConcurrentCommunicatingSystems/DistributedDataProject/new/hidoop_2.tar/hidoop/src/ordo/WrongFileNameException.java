package ordo;

public class WrongFileNameException extends Exception {

	private static final long serialVersionUID = 1L;

	public WrongFileNameException() {
		super();
	}

}
