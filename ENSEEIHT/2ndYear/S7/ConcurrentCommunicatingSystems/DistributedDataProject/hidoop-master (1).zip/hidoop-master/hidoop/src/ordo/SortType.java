package ordo;

public enum SortType {
	Mot, Entier;

}
